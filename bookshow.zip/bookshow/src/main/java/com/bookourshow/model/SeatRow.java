package com.bookourshow.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQuery;

@Entity(name="seat_row")
@NamedNativeQuery(name="SeatRow.getRowId",query="select * from seat_row where row_code=?;")
public class SeatRow {

	@Id
	@Column(name="row_id")
	@GeneratedValue( strategy = GenerationType.IDENTITY)
	private int rowId;
	
	@Column(name="row_code")
	private String rowCode;
	
	public SeatRow() {
		// TODO Auto-generated constructor stub
	}

	public SeatRow(int rowId, String rowCode) {
		super();
		this.rowId = rowId;
		this.rowCode = rowCode;
	}

	public int getRowId() {
		return rowId;
	}

	public void setRowId(int rowId) {
		this.rowId = rowId;
	}

	public String getRowCode() {
		return rowCode;
	}

	public void setRowCode(String rowCode) {
		this.rowCode = rowCode;
	}

	@Override
	public String toString() {
		return "SeatRow [rowId=" + rowId + ", rowCode=" + rowCode + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rowCode == null) ? 0 : rowCode.hashCode());
		result = prime * result + rowId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SeatRow other = (SeatRow) obj;
		if (rowCode == null) {
			if (other.rowCode != null)
				return false;
		} else if (!rowCode.equals(other.rowCode))
			return false;
		if (rowId != other.rowId)
			return false;
		return true;
	}

	
}
