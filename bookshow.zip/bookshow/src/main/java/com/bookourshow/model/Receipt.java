package com.bookourshow.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedAttributeNode;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;

@Entity(name="receipt")
@NamedNativeQueries({
	@NamedNativeQuery(name="Receipt.fetchAllSeats",query="select r.*,c.* from seat_row r cross join seat_column c ;"),
	@NamedNativeQuery(name="Receipt.fetchBookedSeats",query="select sc.*,sr.* from booking b join receipt r join seat_row sr join seat_column sc "+ 
			 "on sc.column_id=r.fk_column_id and sr.row_id=r.fk_row_id and b.booking_id=r.fk_booking_id "+
			 "where b.fk_venue_schedule_id=? and b.bookdate=?;"),
	@NamedNativeQuery(name="registerReceipt",query="insert into receipt(fk_booking_id,fk_column_id,fk_row_id) values(?,?,?);")
})
public class Receipt {

	@ManyToOne(fetch=FetchType.EAGER, cascade=CascadeType.ALL)
	@JoinColumn(name="fk_booking_id")
	private Booking booking;
	
	@ManyToOne(fetch=FetchType.EAGER, cascade=CascadeType.ALL)
	@JoinColumn(name="fk_column_id")
	private SeatColumn seatColumn;
	
	@ManyToOne(fetch=FetchType.EAGER, cascade=CascadeType.ALL)
	@JoinColumn(name="fk_row_id")
	private SeatRow seatRow;
	
	@Id
	@Column(name="receipt_id")
	private int receiptId;
	
	public Receipt() {
		// TODO Auto-generated constructor stub
	}

	public Receipt(Booking booking, SeatColumn seatColumn, SeatRow seatRow) {
		super();
		this.booking = booking;
		this.seatColumn = seatColumn;
		this.seatRow = seatRow;
	}

	
	public int getReceiptId() {
		return receiptId;
	}

	public void setReceiptId(int receiptId) {
		this.receiptId = receiptId;
	}

	public Booking getBooking() {
		return booking;
	}

	public void setBooking(Booking booking) {
		this.booking = booking;
	}

	public SeatColumn getSeatColumn() {
		return seatColumn;
	}

	public void setSeatColumn(SeatColumn seatColumn) {
		this.seatColumn = seatColumn;
	}

	public SeatRow getSeatRow() {
		return seatRow;
	}

	public void setSeatRow(SeatRow seatRow) {
		this.seatRow = seatRow;
	}

	@Override
	public String toString() {
		return "Receipt [seatColumn=" + seatColumn + ", seatRow=" + seatRow + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((booking == null) ? 0 : booking.hashCode());
		result = prime * result + ((seatColumn == null) ? 0 : seatColumn.hashCode());
		result = prime * result + ((seatRow == null) ? 0 : seatRow.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Receipt other = (Receipt) obj;
		if (booking == null) {
			if (other.booking != null)
				return false;
		} else if (!booking.equals(other.booking))
			return false;
		if (seatColumn == null) {
			if (other.seatColumn != null)
				return false;
		} else if (!seatColumn.equals(other.seatColumn))
			return false;
		if (seatRow == null) {
			if (other.seatRow != null)
				return false;
		} else if (!seatRow.equals(other.seatRow))
			return false;
		return true;
	}

	
}
