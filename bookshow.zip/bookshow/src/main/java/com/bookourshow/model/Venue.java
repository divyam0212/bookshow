package com.bookourshow.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.OneToOne;
import javax.persistence.Transient;

@Entity(name="venue")
@NamedNativeQuery(name="Venue.fetchTheaters",query="select v.venue_id,v.venue_name,vs.fk_venue_id, group_concat(t.timing_id) as timings,m.movie_id,a.fk_city_id,l.language_id "+
			 "from address a join venue v join venue_schedule vs join  movie_category mc join language l join movie m join timings t "+
			 "on v.fk_address_id=a.address_id and vs.fk_venue_id=v.venue_id and "+
			 "vs.fk_movie_category_id=mc.movie_category_id and mc.fk_language_id = l.language_id and "+
			 "mc.fk_movie_id=m.movie_id and t.timing_id=vs.fk_timings_id "+
			 "where m.movie_id=? and a.fk_city_id=? and l.language_id=? "+
			 "group by vs.fk_venue_id;")
public class Venue {
	
	@Id
	@Column(name="venue_id")
	@GeneratedValue( strategy = GenerationType.IDENTITY)
	private int venueId;
	
	@Column(name="venue_name")
	private String venueName;
	
	@OneToOne(fetch=FetchType.EAGER, cascade=CascadeType.ALL)
	@JoinColumn(name="fk_address_id")
	private Address address;
	
	@Transient
	private List<Timings> timingList;
	public Venue() {
		super();
	}
	
	public Venue(int venueId, String venueName, Address address) {
		super();
		this.venueId = venueId;
		this.venueName = venueName;
		this.address = address;
	}
	
	
	public Venue(int venueId, String venueName, List<Timings> timingList) {
		super();
		this.venueId = venueId;
		this.venueName = venueName;
		this.timingList = timingList;
	}

	public int getVenueId() {
		return venueId;
	}
	
	public void setVenueId(int venueId) {
		this.venueId = venueId;
	}
	
	public String getVenueName() {
		return venueName;
	}
	
	public void setVenueName(String venueName) {
		this.venueName = venueName;
	}
	
	public Address getAddress() {
		return address;
	}
	
	public void setAddress(Address address) {
		this.address = address;
	}
	
	public List<Timings> getTimingList() {
		return timingList;
	}

	public void setTimingList(List<Timings> timingList) {
		this.timingList = timingList;
	}
	
	
	
	@Override
	public String toString() {
		return "Venue [venueId=" + venueId + ", venueName=" + venueName + ", address=" + address + ", timingList="
				+ timingList + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + venueId;
		result = prime * result + ((venueName == null) ? 0 : venueName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Venue other = (Venue) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (venueId != other.venueId)
			return false;
		if (venueName == null) {
			if (other.venueName != null)
				return false;
		} else if (!venueName.equals(other.venueName))
			return false;
		return true;
	}

	

}
