package com.bookourshow.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;

@Entity(name="booking")
@NamedNativeQueries({
	@NamedNativeQuery(name="Booking.registerBooking" , query="insert into booking(fk_user_id,fk_venue_schedule_id,bookdate) values(?,?,?);"),
	@NamedNativeQuery(name="Booking.updateBooking" , query="update booking set no_of_seats=?,amount=? where booking_id=?;"),
	@NamedNativeQuery(name="Booking.generateBill" , query="select e.fk_booking_id,sum(e.amount) as price,count(e.fk_row_id) as totseats from "
	+"(select r.fk_booking_id,p.amount,sp.fk_row_id "
	+"from seat_price sp join price p join receipt r "
	+"on sp.fk_price_id=p.price_id and sp.fk_row_id=r.fk_row_id)e "
	+"where e.fk_booking_id=? "
	+"group by e.fk_booking_id;")
})
public class Booking {

	@Id
	@Column(name="booking_id")
	@GeneratedValue( strategy = GenerationType.IDENTITY)
	private int bookingId;
	
	@Column(name="no_of_seats")
	private int noOfSeats;
	
	@ManyToOne(fetch=FetchType.EAGER, cascade=CascadeType.ALL)
	@JoinColumn(name="fk_user_id")
	private User user;
	
	@ManyToOne(fetch=FetchType.EAGER, cascade=CascadeType.ALL)
	@JoinColumn(name="fk_venue_schedule_id")
	private VenueSchedule venueSchedule;
	
	@Column(name="bookdate")
	private String bookDate;
	
	@Column(name="amount")
	private float amount;
	
	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	public Booking() {
		// TODO Auto-generated constructor stub
	}

	public Booking(int bookingId, int noOfSeats, User user, VenueSchedule venueSchedule, String bookDate) {
		super();
		this.bookingId = bookingId;
		this.noOfSeats = noOfSeats;
		this.user = user;
		this.venueSchedule = venueSchedule;
		this.bookDate = bookDate;
	}

	

	public Booking(User user, VenueSchedule venueSchedule, String bookDate) {
		super();
		this.user = user;
		this.venueSchedule = venueSchedule;
		this.bookDate = bookDate;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public int getNoOfSeats() {
		return noOfSeats;
	}

	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public VenueSchedule getVenueSchedule() {
		return venueSchedule;
	}

	public void setVenueSchedule(VenueSchedule venueSchedule) {
		this.venueSchedule = venueSchedule;
	}

	public String getBookDate() {
		return bookDate;
	}

	public void setBookDate(String bookDate) {
		this.bookDate = bookDate;
	}

	
	@Override
	public String toString() {
		return "Booking [bookingId=" + bookingId + ", noOfSeats=" + noOfSeats + ", user=" + user + ", venueSchedule="
				+ venueSchedule + ", bookDate=" + bookDate + ", amount=" + amount + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bookDate == null) ? 0 : bookDate.hashCode());
		result = prime * result + bookingId;
		result = prime * result + noOfSeats;
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		result = prime * result + ((venueSchedule == null) ? 0 : venueSchedule.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Booking other = (Booking) obj;
		if (bookDate == null) {
			if (other.bookDate != null)
				return false;
		} else if (!bookDate.equals(other.bookDate))
			return false;
		if (bookingId != other.bookingId)
			return false;
		if (noOfSeats != other.noOfSeats)
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		if (venueSchedule == null) {
			if (other.venueSchedule != null)
				return false;
		} else if (!venueSchedule.equals(other.venueSchedule))
			return false;
		return true;
	}
	
	
}
