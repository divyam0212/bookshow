package com.bookourshow.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bookourshow.model.Address;
import com.bookourshow.model.Booking;
import com.bookourshow.model.City;
import com.bookourshow.model.Language;
import com.bookourshow.model.Movie;
import com.bookourshow.model.MovieCategory;
import com.bookourshow.model.Receipt;
import com.bookourshow.model.Venue;
import com.bookourshow.repo.AddressRepoService;
import com.bookourshow.repo.BookingRepoService;
import com.bookourshow.repo.CategoryRepoService;
import com.bookourshow.repo.LanguageRepoService;
import com.bookourshow.repo.MovieCategoryRepoService;
import com.bookourshow.repo.MovieRepoService;
import com.bookourshow.repo.ReceiptRepoService;
import com.bookourshow.repo.TimingRepoService;
import com.bookourshow.repo.UserRepoService;
import com.bookourshow.repo.VenueRepoService;
import com.bookourshow.repo.VenueScheduleRepoService;

@RestController
public class RepoController {

	@Autowired(required=true)
	AddressRepoService addressRepoService;
	
	@Autowired(required=true)
	BookingRepoService bookingRepoService;
	
	@Autowired(required=true)
	CategoryRepoService categoryRepoService;
	
	@Autowired(required=true)
	LanguageRepoService languageRepoService;
	
	@Autowired(required=true)
	MovieCategoryRepoService movieCategoryRepoService;
	
	@Autowired(required=true)
	ReceiptRepoService receiptRepoService;
	
	@Autowired(required=true)
	TimingRepoService timingRepoService;
	
	@Autowired(required=true)
	UserRepoService userRepoService;
	
	@Autowired(required=true)
	VenueRepoService venueRepoService;
	
	@Autowired(required=true)
	VenueScheduleRepoService venueScheduleRepoService;
	
	@GetMapping("/alladdress")
	public List<Address> allAddress(){
		List<Address> list =addressRepoService.allAddress();
		return list;
	}
	@GetMapping("/allmovies")
	public List<MovieCategory> fetchAllMovie(){
		return movieCategoryRepoService.fetchAllMovie();
	}
	@PostMapping("/languagebycityandmovie")
	public List<Language> fetchLanguageByMovieAndCity(@RequestBody String[] parameterFetch){
		int movieId=Integer.parseInt(parameterFetch[0]);
		int cityId=Integer.parseInt(parameterFetch[1]);
		return languageRepoService.fetchLanguageByMovieAndCity(movieId,cityId);
	}
	@PostMapping("/venuebycityandmovieandlanguage")
	public List<Venue> fetchTheaters(@RequestBody String[] parameterFetch){
		int movieId=Integer.parseInt(parameterFetch[0]);
		int cityId=Integer.parseInt(parameterFetch[1]);
		int languageId=Integer.parseInt(parameterFetch[2]);
		return venueRepoService.fetchTheaters(movieId, cityId, languageId);
		
	}
	@PostMapping("/fetchallbookedseats")
	public List<Receipt> fetchBookedSeats(@RequestBody String[] parameterFetch){
		int venueScheduleid=Integer.parseInt(parameterFetch[0]);
		String bookDate= parameterFetch[1];
		return receiptRepoService.fetchBookedSeats(venueScheduleid, bookDate);
		
	}
	@PostMapping("/generatebill")
	public List<Booking> generateBill(@RequestBody String[] parameterFetch){
		int bookingId=Integer.parseInt(parameterFetch[0]);
		return bookingRepoService.generateBill(bookingId);
	}
	
	
}
