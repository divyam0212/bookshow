package com.bookourshow.repo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;

import com.bookourshow.model.Language;

public class LanguageRepoService {

	public LanguageRepoService() {
		// TODO Auto-generated constructor stub
	}
	@Autowired(required=true)
	LanguageRepository languageRepository;
	public List<Language> fetchLanguageByMovieAndCity(@Param("movie_id") int movieId,@Param("fk_city_id") int cityId){
		return languageRepository.fetchLanguageByMovieAndCity(movieId, cityId);
	}
	
}
