package com.bookourshow.repo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.bookourshow.model.Address;

public class AddressRepoService {

	public AddressRepoService() {
		// TODO Auto-generated constructor stub
	}
	@Autowired(required=true)
	AddressRepository addressRepository;
	
	public List<Address> allAddress(){
		List<Address> list = addressRepository.fetchAllLocation();
		return list;
	}
	
}
