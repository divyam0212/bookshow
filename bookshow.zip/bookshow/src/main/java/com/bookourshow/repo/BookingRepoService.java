package com.bookourshow.repo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;

import com.bookourshow.model.Booking;

public class BookingRepoService {

	public BookingRepoService() {
		// TODO Auto-generated constructor stub
	}
	@Autowired(required=true)
	BookingRepository bookingRepository;
	public List<Booking> generateBill(@Param("fk_booking_id") int bookingId)
	{
		return bookingRepository.generateBill(bookingId);
	}
}
