package com.bookourshow.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bookourshow.model.Category;

public interface CategoryRepository extends JpaRepository<Category, Integer> {

}
