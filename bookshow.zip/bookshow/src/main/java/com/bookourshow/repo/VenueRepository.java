package com.bookourshow.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import com.bookourshow.model.Venue;

public interface VenueRepository extends JpaRepository<Venue, Integer> {
	public List<Venue> fetchTheaters(@Param("movie_id") int movieId,@Param("fk_city_id") int cityId,@Param("language_id") int languageId);
}
