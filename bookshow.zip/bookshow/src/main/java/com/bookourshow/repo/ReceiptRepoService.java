package com.bookourshow.repo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;

import com.bookourshow.model.Receipt;

public class ReceiptRepoService {

	public ReceiptRepoService() {
		// TODO Auto-generated constructor stub
	}

	@Autowired(required = true)
	ReceiptRepository receiptRepository;

	public List<Receipt> fetchBookedSeats(@Param("fk_venue_schedule_id") int venueScheduleId,
			@Param("bookdate") String bookDate) {
		return receiptRepository.fetchBookedSeats(venueScheduleId, bookDate);
	}

}
