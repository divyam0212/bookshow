package com.bookourshow.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import com.bookourshow.model.Language;

public interface LanguageRepository extends JpaRepository<Language, Integer> {
	public List<Language> fetchLanguageByMovieAndCity(@Param("movie_id") int movieId,@Param("fk_city_id") int cityId);
}
