package com.bookourshow.repo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.bookourshow.model.MovieCategory;

public class MovieCategoryRepoService {

	public MovieCategoryRepoService() {
		// TODO Auto-generated constructor stub
	}
	@Autowired(required=true)
	MovieCategoryRepository movieCategoryRepository;
	
	public List<MovieCategory> fetchAllMovie(){
		return movieCategoryRepository.fetchAllMovie();
	}
}
