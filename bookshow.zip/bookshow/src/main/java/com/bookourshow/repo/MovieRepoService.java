package com.bookourshow.repo;

public class MovieRepoService {

	public MovieRepoService() {
		// TODO Auto-generated constructor stub
	}

}
