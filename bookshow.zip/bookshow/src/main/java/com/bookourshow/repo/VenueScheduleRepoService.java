package com.bookourshow.repo;

public class VenueScheduleRepoService {

	public VenueScheduleRepoService() {
		// TODO Auto-generated constructor stub
	}

}
