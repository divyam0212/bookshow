package com.bookourshow.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import com.bookourshow.model.Booking;

public interface BookingRepository extends JpaRepository<Booking, Integer> {
	public List<Booking> generateBill(@Param("fk_booking_id") int bookingId);

}
