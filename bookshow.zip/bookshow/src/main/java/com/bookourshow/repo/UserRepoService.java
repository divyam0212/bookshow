package com.bookourshow.repo;

public class UserRepoService {

	public UserRepoService() {
		// TODO Auto-generated constructor stub
	}

}
