package com.bookourshow.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bookourshow.exception.BookOurShowException;
import com.bookourshow.model.Address;

public interface AddressRepository extends JpaRepository<Address, Integer> {
	public List<Address> fetchAllLocation();
}
