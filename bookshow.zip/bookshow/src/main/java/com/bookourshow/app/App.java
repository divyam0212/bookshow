package com.bookourshow.app;

import javax.persistence.Entity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
//import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
//import org.springframework.context.annotation.ComponentScan;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.JstlView;
import org.springframework.web.servlet.view.UrlBasedViewResolver;

import com.bookourshow.controller.RepoController;
import com.bookourshow.controller.TestController;
import com.bookourshow.model.MovieCategory;
import com.bookourshow.repo.AddressRepoService;
import com.bookourshow.repo.BookingRepoService;
import com.bookourshow.repo.CategoryRepoService;
import com.bookourshow.repo.LanguageRepoService;
import com.bookourshow.repo.MovieCategoryRepoService;
import com.bookourshow.repo.MovieRepoService;
import com.bookourshow.repo.ReceiptRepoService;
import com.bookourshow.repo.TimingRepoService;
import com.bookourshow.repo.UserRepoService;
import com.bookourshow.repo.VenueRepoService;
import com.bookourshow.repo.VenueScheduleRepoService;
import com.bookourshow.service.AddressService;
import com.bookourshow.service.BookingService;
import com.bookourshow.service.CategoryService;
import com.bookourshow.service.LanguageService;
import com.bookourshow.service.MovieCategoryService;
import com.bookourshow.service.MovieService;
import com.bookourshow.service.ReceiptService;
import com.bookourshow.service.TimingsService;
import com.bookourshow.service.UserService;
import com.bookourshow.service.VenueScheduleService;
import com.bookourshow.service.VenueService;


/*@Configuration
@ComponentScan({"com.payroll"})
@EnableWebMvc
@EnableAutoConfiguration*/


@EntityScan("com.bookourshow.*")
@EnableJpaRepositories(value="com.bookourshow.repo")

@SpringBootApplication
public class App extends SpringBootServletInitializer {

	
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		// TODO Auto-generated method stub
		return builder.sources(App.class);
	}
	
	@Bean
	public AddressRepoService addressRepoService(){
		return new AddressRepoService();
	}
	
	@Bean
	public RepoController repoController(){
		return new RepoController();
	}
	
	
	@Bean
	public BookingRepoService bookingRepoService(){
		return new BookingRepoService();
	}
	@Bean
	public CategoryRepoService categoryRepoService(){
		return new CategoryRepoService();
	}
	@Bean
	public LanguageRepoService languageRepoService(){
		return new LanguageRepoService();
	}
	@Bean
	public MovieCategoryRepoService movieCategoryRepoService(){
		return new MovieCategoryRepoService();
	}
	@Bean
	public MovieRepoService movieRepoService(){
		return new  MovieRepoService();
	}
	@Bean 
	public ReceiptRepoService receiptRepoService(){
		return new ReceiptRepoService();
	}
	@Bean
	public TimingRepoService timingRepoService(){
		return new TimingRepoService();
	}
	@Bean 
	public UserRepoService userRepoService(){
		return new UserRepoService();
	}
	@Bean 
	public VenueScheduleRepoService venueScheduleRepoService(){
		return new VenueScheduleRepoService();
	}
	@Bean
	public VenueRepoService venueRepoService(){
		return new VenueRepoService();
	}
	
	@Bean
	public UrlBasedViewResolver setUpViewResolver(){
		UrlBasedViewResolver resolver=new UrlBasedViewResolver();
		resolver.setPrefix("/WEB-INF/views/");
		resolver.setSuffix(".jsp");
		resolver.setViewClass(JstlView.class);
		
		return resolver;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SpringApplication.run(App.class, args);
	}

}
